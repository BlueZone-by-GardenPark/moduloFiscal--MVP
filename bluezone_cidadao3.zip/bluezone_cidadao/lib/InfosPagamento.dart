import 'package:flutter/material.dart';

class InfosPagamento extends StatefulWidget {
  const InfosPagamento({Key? key}) : super(key: key);

  @override
  State<InfosPagamento> createState() => _InfosPagamentoState();
}

class _InfosPagamentoState extends State<InfosPagamento> {

  TextEditingController _controllerPlaca = TextEditingController();
  TextEditingController _controllerCPF = TextEditingController();

  String dropdownValue = '';
  final _dropdownFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(top: 80),
              ),
              Padding(
                padding: EdgeInsets.all(32),
                child: TextField(
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: "Placa",
                  ),
                  style: TextStyle(
                      fontSize: 22
                  ),
                  controller: _controllerPlaca,
                ),
              ),
              Padding(
                padding: EdgeInsets.all(32),
                child: TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: "CPF",
                  ),
                  style: TextStyle(
                      fontSize: 22
                  ),
                  controller: _controllerCPF,
                ),
              ),
              Padding(
                padding: EdgeInsets.all(32),
                  child: Form(
                      key: _dropdownFormKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          DropdownButtonFormField(
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.blue, width: 2),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.blue, width: 2),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                filled: true,
                                fillColor: Colors.white,
                              ),
                              validator: (value) => value == null ? "Select a country" : null,
                              dropdownColor: Colors.white,
                              value: dropdownValue,
                              onChanged: (String? newValue) {
                                setState(() {
                                  dropdownValue = newValue!;
                                });
                              },
                              items: <String>['30 minutos', '1 hora', '2 horas', '3 horas']
                                  .map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),),
                          ElevatedButton(
                              onPressed: () {
                                if (_dropdownFormKey.currentState!.validate()) {
                                  //valid flow
                                }
                              },
                              child: Text("Submit"))
                        ],
                      ),
                  ),
              ),
            ],
          ),
        )
        )
      );
  }
}

