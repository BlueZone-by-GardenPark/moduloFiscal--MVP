import 'package:bluezone_cidadao/PagamentoCartao.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:validadores/Validador.dart';

class InfosPagamento extends StatefulWidget {

  @override
  State<InfosPagamento> createState() => _InfosPagamentoState();

}

class _InfosPagamentoState extends State<InfosPagamento> {

  String? dropValue;
  final dropOptions = ['1 Hora', '2 Horas', '3 Horas', '4 Horas'];

  TextEditingController _controllerPlaca = TextEditingController();
  TextEditingController _controllerCPF = TextEditingController();

  _salvarInfos()async{
    FirebaseFirestore db = FirebaseFirestore.instance;

      DocumentReference ref = await db.collection("Veículo")
          .add(
          {
            "CPF" : _controllerCPF.text,
            "Placa" : _controllerPlaca.text.toUpperCase(),
            "Estadia(h)" : dropValue,
            "Dia/Hora" : DateTime.now().toLocal().toString()
          }
      );
  }

  @override
  void initState() {
    super.initState();
    Firebase.initializeApp();
    dropValue = dropOptions[0];
  }

  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormFieldState>();
    final _formKey1 = GlobalKey<FormFieldState>();
    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(top: 60, left: 40, right: 40),
        color: Color(0xFFE5EEFFFF),
        child: ListView(
          children: <Widget>[
            TextFormField(
              maxLength: 7,
              key: _formKey1,
              controller: _controllerPlaca,
              // autofocus: true,
              keyboardType: TextInputType.text,
              validator: (value){
                if(value!.isEmpty) return "Campo obrigatório";
              },
              decoration: InputDecoration(
                helperText: 'Informe sua Placa',
                hintText: 'XXX1234',
                labelText: 'Placa',
              ),
              style: TextStyle(fontSize: 20),
            ),
            Padding(
              padding: EdgeInsets.only(top: 40),
              child: TextFormField(
                maxLength: 11,
                key: _formKey,
                controller: _controllerCPF,
                // autofocus: true,
                keyboardType: TextInputType.number,
                validator: (value){
                  return Validador()
                      .add(Validar.CPF, msg: 'CPF Inválido')
                      .add(Validar.OBRIGATORIO, msg: 'Campo obrigatório')
                      .minLength(11)
                      .maxLength(11)
                      .valido(value,clearNoNumber: true);
                },
                decoration: InputDecoration(
                    helperText: 'Informe seu CPF',
                    hintText: 'XXX.XXX.XXX-XX',
                    labelText: 'CPF',
                ),
                style: TextStyle(fontSize: 20),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 60),
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 4, horizontal: 12),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.black.withOpacity(0.3), width: 0.9)
                ),
                child: DropdownButton<String>(
                    value: dropValue!.isNotEmpty ? dropValue : null,
                    //hint: Text("Quantidade Horas"),
                    isExpanded: true,
                    iconSize: 26,
                    items: dropOptions
                        .map((item) => DropdownMenuItem<String>(
                      value: item,
                      child: Text(item, style: TextStyle(fontSize: 24),),
                    ))
                        .toList(),
                    onChanged: (item) => setState(()=> dropValue = item,)
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 60),
              child: Container(
                height: 60,
                alignment: Alignment.centerLeft,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: [0.3, 1],
                    colors: [
                      Color(0xFFF58524),
                      Color(0XFFF92B7F),
                    ],
                  ),
                  borderRadius: BorderRadius.all(
                    Radius.circular(5),
                  ),
                ),
                child: SizedBox.expand(
                  child: FlatButton(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          "Pagamento por PIX",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 20,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ],
                    ),
                    onPressed: () {
                      if(_formKey.currentState!.validate() && _formKey1.currentState!.validate()){
                        _salvarInfos();
                      }
                      //Navigator.push(
                        //context,
                        //MaterialPageRoute(
                          //builder: (context) => Home(),
                        //),
                      //);
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Container(
                height: 60,
                alignment: Alignment.centerLeft,
                decoration: BoxDecoration(
                  color: Color(0xFF3C5A99),
                  borderRadius: BorderRadius.all(
                    Radius.circular(5),
                  ),
                ),
                child: SizedBox.expand(
                  child: FlatButton(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          "Pagamento por Cartão",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 20,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ],
                    ),
                    onPressed: () {
                      if(_formKey.currentState!.validate() && _formKey1.currentState!.validate()){
                        _salvarInfos();
                        Navigator.push(
                        context,
                        MaterialPageRoute(
                        builder: (context) => PagamentoCartao(),
                        ),
                        );
                      }
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}