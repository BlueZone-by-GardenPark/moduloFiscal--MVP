package br.com.zonaazul.projetofiscal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.com.zonaazul.projetofiscal.databinding.ActivityRegistroIrregBinding
import com.google.android.material.button.MaterialButton

class RegistroIrregActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroIrregBinding
    private lateinit var btnBack: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroIrregBinding.inflate(layoutInflater)
        setContentView(binding.root)

        btnBack = findViewById(R.id.btnBack)

        binding.btnOpenCamera.setOnClickListener{

            openCamera()
        }

        btnBack.setOnClickListener{
            backPage()
        }
    }

    private fun openCamera(){
        val intentOpenCamera = Intent(this, CameraActivity::class.java)
        startActivity(intentOpenCamera)
    }

    private fun backPage(){
        val back = Intent(this, StatusVeiculoActivity::class.java)
        startActivity(back)
    }
}