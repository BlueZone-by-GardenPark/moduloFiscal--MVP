import 'package:bluezone_cidadao/InfosPagamento.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

import 'package:permission_handler/permission_handler.dart';

class Mapa extends StatefulWidget {
  @override
  _MapaState createState() => _MapaState();
}

class _MapaState extends State<Mapa> {

  Future<void> requestPermission() async { await Permission.location.request(); }

  Completer<GoogleMapController> _controller = Completer();

  CameraPosition _posicaoCamera = CameraPosition(
      target: LatLng(-22.884891, -47.069672),
  );

  Set<Polygon> _polygons = {};

  _onMapCreated( GoogleMapController controller ){
    _controller.complete( controller );
  }

  _adicionarListenerLocalizacao(){

    var geolocator = Geolocator();
    var locationOptions = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10
    );

    Geolocator.getPositionStream( locationSettings: locationOptions ).listen((Position position){

      _posicaoCamera = CameraPosition(
          target: LatLng(position.latitude, position.longitude),
          zoom: 16
      );

      _movimentarCamera( _posicaoCamera );

    });

  }

  _recuperaUltimaLocalizacaoConhecida() async {

    Position? position = await Geolocator.getLastKnownPosition();

    setState(() {
      if( position != null ){
        _posicaoCamera = CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 16
        );

        _movimentarCamera( _posicaoCamera );

      }
    });

  }

  _movimentarCamera( CameraPosition cameraPosition ) async {

    GoogleMapController googleMapController = await _controller.future;
    googleMapController.animateCamera(
        CameraUpdate.newCameraPosition(
            cameraPosition
        )
    );

  }

  @override
  void initState() {
    super.initState();
    requestPermission();
    _recuperaUltimaLocalizacaoConhecida();
    _adicionarListenerLocalizacao();
    _carregarArea();
  }

  _showAlertDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Jardim Guanabara"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                    TextSpan(
                        text: "\n\nHorário de Funcionamento:",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                          TextSpan(
                              text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                              style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                              children: <InlineSpan>[
                                TextSpan(
                                    text: "\n\nValores:",
                                    style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                    children: <InlineSpan>[
                                      TextSpan(
                                        text: "\n1 hora: R\$ 1.50\n2 horas: R\$ 2.50\n3 horas: R\$ 3.50\n4 horas: R\$ 4.50",
                                        style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                      )
                                    ]
                                )
                              ]
                          )
                        ]
                    ),
                  )],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("PROSSEGUIR"),
                onPressed: (){
                  Navigator.push(
                  context,
                  MaterialPageRoute(
                  builder: (context) => InfosPagamento()
                  )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _showAlertDialog1(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Jardim Chapadão"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                    TextSpan(
                        text: "\n\nHorário de Funcionamento:",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                          TextSpan(
                              text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                              style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                              children: <InlineSpan>[
                                TextSpan(
                                    text: "\n\nValores:",
                                    style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                    children: <InlineSpan>[
                                      TextSpan(
                                        text: "\n1 hora: R\$ 1.50\n2 horas: R\$ 2.50\n3 horas: R\$ 3.50\n4 horas: R\$ 4.50",
                                        style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                      )
                                    ]
                                )
                              ]
                          )
                        ]
                    ),
                  )],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("PROSSEGUIR"),
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => InfosPagamento()
                      )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _showAlertDialog2(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Região Botafogo"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                    TextSpan(
                        text: "\n\nHorário de Funcionamento:",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                          TextSpan(
                              text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                              style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                              children: <InlineSpan>[
                                TextSpan(
                                    text: "\n\nValores:",
                                    style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                    children: <InlineSpan>[
                                      TextSpan(
                                        text: "\n1 hora: R\$ 1.50\n2 horas: R\$ 2.50\n3 horas: R\$ 3.50\n4 horas: R\$ 4.50",
                                        style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                      )
                                    ]
                                )
                              ]
                          )
                        ]
                    ),
                  )],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("PROSSEGUIR"),
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => InfosPagamento()
                      )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _carregarArea() {

    Set<Polygon> listaPolygons = {};
    Polygon polygon1 = Polygon(
        consumeTapEvents: true,
        onTap: (){
          _showAlertDialog(context);
        },
        polygonId: PolygonId("polygon1"),
        fillColor: Colors.blue.withOpacity(0.5),
        strokeColor: Colors.blue,
        strokeWidth: 10,
        points: [
          LatLng(-22.884891, -47.069672),
          LatLng(-22.887850, -47.070469),
          LatLng(-22.891000, -47.068169),
          LatLng(-22.889003, -47.065165),
        ]
    );
    Polygon polygon2 = Polygon(
        consumeTapEvents: true,
        onTap: (){
          _showAlertDialog2(context);
        },
        polygonId: PolygonId("polygon2"),
        fillColor: Colors.blue.withOpacity(0.5),
        strokeColor: Colors.blue,
        strokeWidth: 10,
        points: [
          LatLng(-22.894429, -47.077783),
          LatLng(-22.900241, -47.080830),
          LatLng(-22.902424, -47.074923),
          LatLng(-22.895625, -47.072821),
        ]
    );
    Polygon polygon3 = Polygon(
        consumeTapEvents: true,
        onTap: (){
          _showAlertDialog1(context);
        },
        polygonId: PolygonId("polygon3"),
        fillColor: Colors.blue.withOpacity(0.5),
        strokeColor: Colors.blue,
        strokeWidth: 10,
        points: [
          LatLng(-22.895051, -47.085631),
          LatLng(-22.899104, -47.085996),
          LatLng(-22.899549, -47.082777),
          LatLng(-22.896069, -47.080996),
        ]
    );
    listaPolygons.add(polygon1);
    listaPolygons.add(polygon2);
    listaPolygons.add(polygon3);

    setState(() {
      _polygons = listaPolygons;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: <Widget>[
            GoogleMap(
              mapType: MapType.normal,
              initialCameraPosition: _posicaoCamera,
              onMapCreated: _onMapCreated,
              myLocationEnabled: true,
              polygons: _polygons,
            ),
            Container(
                alignment: Alignment.topCenter,
                padding: EdgeInsets.only(top: 80),
                child: const Text(
                  "Clique na área desejada:",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    backgroundColor: Colors.white,
                  ),
                )
            ),
          ],
        ),
      ),
    );
  }
}
