import 'package:bluezone_cidadao/HomePage.dart';
import 'package:bluezone_cidadao/Ticket.dart';
import 'package:bluezone_cidadao/api/notifications_api.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_countdown_timer/flutter_countdown_timer.dart';
import 'package:flutter_credit_card_brazilian/credit_card_form.dart';
import 'package:flutter_credit_card_brazilian/credit_card_model.dart';
import 'package:flutter_credit_card_brazilian/flutter_credit_card.dart';
import 'dart:convert';
import 'dart:math';
import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class PagamentoCartao extends StatefulWidget {

  String placa;
  String cpf;
  String estadia;
  String pagamento;
  PagamentoCartao(this.placa, this.cpf, this.estadia, this.pagamento);

  @override
  State<StatefulWidget> createState() {
    return PagamentoCartaoState();
  }
}

class PagamentoCartaoState extends State<PagamentoCartao> {

  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    NotificationAPI.init();
    listenNotifications();
  }


  void listenNotifications() =>{
    NotificationAPI.onNotifications.stream.listen(onClickedNotification1),
    NotificationAPI1.onNotifications1.stream.listen(onClickedNotification)
  };

  void onClickedNotification1(String? payload) =>{
  };

  void onClickedNotification(String? payload) =>{
    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => Home())),
  };

  _salvarPagamento() async {

    String valor;
    String horario;
    String meucpf;
    String datahora;
    String minhaplaca;

    valor = widget.pagamento;
    horario = widget.estadia;
    meucpf = widget.cpf;
    datahora = DateTime.now().toLocal().toString();
    minhaplaca = widget.placa;

    var _random = Random.secure();
    var random = List<int>.generate(32, (i) => _random.nextInt(256));
    var verificador = base64Url.encode(random);

    FirebaseFirestore db = FirebaseFirestore.instance;
    DocumentReference ref = await
    db.collection("Veículo")
        .add(
        {
          "CPF" : widget.cpf,
          "Placa" : widget.placa.toUpperCase(),
          "Estadia(h)" : widget.estadia,
          "Token" : verificador,
          "Pagamento" : 1,
          "Dia/Hora" : DateTime.now().toLocal().toString()
        }
    );
    void updatePag(){
      FirebaseFirestore.instance
          .collection("Veículo")
          .doc(ref.id)
          .update({
        "Pagamento" : 0
      }).then((result){
        print("Alterado");
      }).catchError((onError){
        print("Não Alterado");
      });
    }

    void update(){
      const timeoutt = const Duration(seconds: 20);
      const mss = const Duration(milliseconds: 1);

      void handleTimeout() {
        NotificationAPI.showNotification(
          title: 'BlueZone - Sua Estadia',
          body: 'Sua estadia acabou.',
          payload: 'Estadia',
        );
        updatePag();
      }

      _startTimeoutt([int? milliseconds]) {
        var duration = milliseconds == null ? timeoutt : mss * milliseconds;
        return Timer(duration, handleTimeout);
      }

      _startTimeoutt();
    }

    const timeout = const Duration(seconds: 10);
    const ms = const Duration(milliseconds: 1);

    void handleTimeoutt() {
      NotificationAPI1.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Faltam 5 minutos para acabar sua estadia.',
        payload: 'Estadia',
      );
      update();
    }

    _startTimeout([int? milliseconds]) {
      var duration = milliseconds == null ? timeout : ms * milliseconds;
      return Timer(duration, handleTimeoutt);
    }

    if(horario == '1 Hora'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
      _startTimeout();
    }else if(horario == '2 Horas'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
    }else if(horario == '3 Horas'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
    }else if(horario == '4 Horas'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
    }
    print("salvou");
    Navigator.push(
    context,
    MaterialPageRoute(
    builder: (context) => TicketWidget(valor, horario, meucpf, datahora, minhaplaca)
    )
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        backgroundColor: Color(0xFFE5EEFFFF),
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(top: 60),
                child: CreditCardWidget(
                  cardName: (String value) {
                    print(value);
                  },
                  cardNumber: cardNumber,
                  expiryDate: expiryDate,
                  cardHolderName: cardHolderName,
                  cvvCode: cvvCode,
                  showBackView: isCvvFocused,
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      CreditCardForm(
                        formKey: formKey,
                        cardNumber: cardNumber,
                        cvvCode: cvvCode,
                        cardHolderName: cardHolderName,
                        expiryDate: expiryDate,
                        themeColor: Colors.blue,
                        cardNumberDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Número do cartão',
                          hintText: 'XXXX XXXX XXXX XXXX',
                        ),
                        expiryDateDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Validade',
                          hintText: 'XX/XX',
                        ),
                        cvvCodeDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'CVV',
                          hintText: 'XXX',
                        ),
                        cardHolderDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Nome completo',
                        ),
                        onCreditCardModelChange: onCreditCardModelChange,
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          primary: const Color(0xff1b447b),
                        ),
                        child: Container(
                          margin: const EdgeInsets.all(8),
                          child: const Text(
                            'Pagar',
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'halter',
                              fontSize: 14,
                              package: 'flutter_credit_card',
                            ),
                          ),
                        ),
                        onPressed: (){
                          if (formKey.currentState!.validate()) {
                            _salvarPagamento();
                          }
                        },
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onCreditCardModelChange(CreditCardModel? creditCardModel) {
    setState(() {
      cardNumber = creditCardModel!.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }
}