import 'dart:async';
import 'package:bluezone_cidadao/HomePage.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  bool show = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    Timer(Duration(seconds: 10), (){
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => Home() )
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Center(
            child: Image.asset('imagens/parking-sign.png'),
          ),
      ),
    );
  }
}

