import 'package:bluezone_cidadao/LoadingPage.dart';
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  home: SplashScreen(),
  debugShowCheckedModeBanner: false,
));