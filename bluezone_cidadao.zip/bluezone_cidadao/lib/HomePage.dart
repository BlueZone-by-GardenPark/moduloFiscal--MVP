import 'dart:ui';
import 'package:flutter/material.dart';
import 'Mapa.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 60),
              child: Text.rich(
                  TextSpan(
                      text: 'Blue',
                      style: TextStyle(fontSize: 48, color: Color(0xFF4B8FFF)),
                      children: <InlineSpan>[
                        TextSpan(
                          text: 'Zone',
                          style: TextStyle(fontSize: 48, color: Colors.white),
                        )
                      ]
                  )
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 0),
              child: Text(
                "By Garden Parking",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 80),
              child: Text(
                  "BEM-VINDO À NOSSA APLICAÇÃO!",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.white
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 50),
              child: Card(
                margin: EdgeInsets.only(left: 20, right: 20),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  children: [
                    Image.asset('imagens/imagemapa.jpg'),
                    ListTile(
                      title: const Text('MAPA'),
                      subtitle: Text(
                        'Acesse o mapa para fazer sua reserva!',
                        style: TextStyle(color: Colors.black.withOpacity(1)),
                      ),
                    ),
                    Row(
                        children: [
                          ButtonBar(
                            children: [
                              FlatButton(
                                child: const Text('ABRIR MAPA'),
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => Mapa()
                                      )
                                  );
                                },
                              ),
                            ],
                          ),
                          ButtonBar(
                            children: [
                              FlatButton(
                                onPressed: () {
                                },
                                child: const Text('AJUDA'),
                              ),
                            ],
                          ),
                        ]
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Color(0xFF403E44)
    );
  }
}
