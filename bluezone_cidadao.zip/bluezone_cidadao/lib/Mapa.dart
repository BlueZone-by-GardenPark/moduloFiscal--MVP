import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() => runApp(Mapa());

class Mapa extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Google Maps Demo',
      home: MapSample(),
    );
  }
}

class MapSample extends StatefulWidget {
  @override
  State<MapSample> createState() => MapSampleState();
}

class MapSampleState extends State<MapSample> {
  Completer<GoogleMapController> _controller = Completer();
  Set<Marker> _marcadores = {};
  Set<Polygon> _polygons = {};

  _onMapCreated (GoogleMapController googleMapController){
  _controller.complete((googleMapController));
  }

  _movimentarCamera() async {
    GoogleMapController googleMapController = await _controller.future;
    googleMapController.animateCamera(
      CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(-22.885751, -47.069082),
            zoom: 20,
            tilt: 45,
            bearing: 45
          )
      )
    );
  }

  _carregarmarcadores(){

    Set<Marker> marcadoresLocal = {};
    Marker marcador1 = Marker(
      markerId: MarkerId("marcador1"),
      position: LatLng(-22.885751, -47.069082)
    );
    Marker marcador2 = Marker(
        markerId: MarkerId("marcador1"),
        position: LatLng(-22.889942, -47.067472)
    );

    marcadoresLocal.add(marcador1);
    marcadoresLocal.add(marcador2);

    setState(() {
      _marcadores = marcadoresLocal;
    });

    Set<Polygon> listaPolygons = {};
    Polygon polygon1 = Polygon(
        polygonId: PolygonId("polygon1"),
      fillColor: Colors.transparent,
      strokeColor: Colors.blue,
      strokeWidth: 10,
      points: [
        LatLng(-22.885751, -47.069082),
        LatLng(-22.887850, -47.070469),
        LatLng(-22.889942, -47.067472),
        LatLng(-22.888084, -47.066249),
        LatLng(-22.885514, -47.068931),
      ]
    );
    listaPolygons.add(polygon1);

    setState(() {
      _polygons = listaPolygons;
    });
  }

  @override
  void initState() {
    super.initState();
    _carregarmarcadores();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.startTop,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.done),
        onPressed: _movimentarCamera,
      ),
      body: Container(
        child: GoogleMap(
          mapType: MapType.normal,
          initialCameraPosition: CameraPosition(
            target: LatLng(-22.885751, -47.069082),
            zoom: 16
          ),
          onMapCreated: _onMapCreated,
          markers: _marcadores,
          polygons: _polygons,
        ),
      ),
    );
  }
}