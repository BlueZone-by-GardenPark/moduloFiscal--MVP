package br.com.zonaazul.projetofiscal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.com.zonaazul.projetofiscal.databinding.ActivityRegistroIrregBinding

class RegistroIrregActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroIrregBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroIrregBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnOpenCamera.setOnClickListener{

            openCamera()
        }
    }

    private fun openCamera(){
        val intentOpenCamera = Intent(this, CameraActivity::class.java)
        startActivity(intentOpenCamera)
    }
}