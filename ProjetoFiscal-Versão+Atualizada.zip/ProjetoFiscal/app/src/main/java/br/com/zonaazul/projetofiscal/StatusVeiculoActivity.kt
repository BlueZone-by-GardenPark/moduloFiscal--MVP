package br.com.zonaazul.projetofiscal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.button.MaterialButton

class StatusVeiculoActivity : AppCompatActivity() {

    private lateinit var btnBack: MaterialButton
    private lateinit var btnOpenRegister: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_status_veiculo)

        btnBack = findViewById(R.id.btnBack)
        btnOpenRegister = findViewById(R.id.btnOpenRegister)

        btnBack.setOnClickListener{
            backPage()
        }
        btnOpenRegister.setOnClickListener{
            openRegister()
        }

    }
    private fun backPage(){
        val back = Intent(this, HomePageActivity::class.java)
        startActivity(back)
    }

    private fun openRegister(){
        val openReg = Intent(this, RegistroIrregActivity::class.java)
        startActivity(openReg)
    }

}
