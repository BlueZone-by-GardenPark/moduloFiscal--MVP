package br.com.zonaazul.projetofiscal

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import com.google.android.material.button.MaterialButton

class ItinerarioActivity : AppCompatActivity() {

    private lateinit var btnBack: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_itinerario)

        btnBack = findViewById(R.id.btnBack)

        btnBack.setOnClickListener{
            backPage()
        }

        val spinner: Spinner = findViewById(R.id.Spinner1)
        ArrayAdapter.createFromResource(
            this,
            R.array.namesSpinner,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        class SpinnerActivity : Activity(), AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                val spinner: Spinner = findViewById(R.id.Spinner1)
                spinner.onItemSelectedListener = this
            }
        }
    }

    private fun backPage(){
        val back = Intent(this, HomePageActivity::class.java)
        startActivity(back)
    }

}