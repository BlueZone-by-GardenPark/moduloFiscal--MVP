import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'InfosPagamento.dart';

class Mapa extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MapSample(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MapSample extends StatefulWidget {
  @override
  State<MapSample> createState() => MapSampleState();
}

class MapSampleState extends State<MapSample> {
  Completer<GoogleMapController> _controller = Completer();

  CameraPosition _cameraposition = CameraPosition(
      target: LatLng(-22.885751, -47.069082),
      zoom: 16
  );

  Set<Marker> _marcadores = {};
  Set<Polygon> _polygons = {};

  _onMapCreated (GoogleMapController googleMapController){
    _controller.complete((googleMapController));
  }

  _adicionarListenerLocalizacao(){

    var geolocator = Geolocator();
    var locationOptions = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100
    );

    Geolocator.getPositionStream( locationSettings: locationOptions ).listen((Position position){

      _cameraposition = CameraPosition(
          target: LatLng(position.latitude, position.longitude),
          zoom: 19
      );

      _movimentarCamera( _cameraposition );

    });
  }

  _recuperaUltimaLocalizacaoConhecida() async {

    Position? position = await Geolocator.getLastKnownPosition();

    //Position? position = await Geolocator.getCurrentPosition( desiredAccuracy: LocationAccuracy.high );

    setState(() {
      if( position != null ){
        _cameraposition = CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 19
        );

        _movimentarCamera( _cameraposition );

      }
    });

  }

  _movimentarCamera( CameraPosition cameraPosition ) async {

    GoogleMapController googleMapController = await _controller.future;
    googleMapController.animateCamera(
        CameraUpdate.newCameraPosition(
            cameraPosition
        )
    );

  }

  @override
  void initState() {
    super.initState();
    _carregarmarcadores();
    _recuperaUltimaLocalizacaoConhecida();
    _adicionarListenerLocalizacao();
  }

  _showAlertDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Sua Reserva"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                    TextSpan(
                        text: "Localização:\n",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                    TextSpan(
                    text: "Rua Frei Antônio de Pádua, 1428 - Jardim Guanabara, Campinas - SP, 13073-330",
                        style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                        children: <InlineSpan>[
                          TextSpan(
                              text: "\n\nHorário de Funcionamento:",
                              style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                              children: <InlineSpan>[
                                TextSpan(
                                    text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                                    style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                    children: <InlineSpan>[
                                      TextSpan(
                                          text: "\n\nPreços:",
                                          style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                          children: <InlineSpan>[
                                            TextSpan(
                                              text: "\n30 min: 1 real\nPor hora: 2 reais",
                                              style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                            )
                                          ]
                                      )
                                    ]
                                )
                              ]
                          ),
                        ],
                    )],
                  ),
                  )],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("RESERVAR"),
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => InfosPagamento()
                      )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _showAlertDialog1(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Sua Reserva"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                    TextSpan(
                        text: "Horário de Funcionamento:",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                          TextSpan(
                              text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                              style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                              children: <InlineSpan>[
                                TextSpan(
                                    text: "\n\nPreços:",
                                    style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                    children: <InlineSpan>[
                                      TextSpan(
                                        text: "\n30 min: 1 real\nPor hora: 2 reais",
                                        style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                      )
                                    ]
                                )
                              ]
                          )
                        ]
                    ),
                  ),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("RESERVAR"),
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => InfosPagamento()
                      )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _showAlertDialog2(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Sua Reserva"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                      TextSpan(
                          text: "Horário de Funcionamento:",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                          TextSpan(
                            text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                            style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                            children: <InlineSpan>[
                              TextSpan(
                                text: "\n\nPreços:",
                                style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                  children: <InlineSpan>[
                                    TextSpan(
                                      text: "\n30 min: 1 real\nPor hora: 2 reais",
                                      style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                    )
                                  ]
                              )
                            ]
                          )
                        ]
                      ),
                  ),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("RESERVAR"),
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => InfosPagamento()
                      )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _showAlertDialog3(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            alignment: Alignment.center,
            title: Text("Sua Reserva"),
            content: SingleChildScrollView(
              child: ListBody(
                children: const <Widget>[
                  Text.rich(
                    TextSpan(
                        text: "Horário de Funcionamento:",
                        style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                        children: <InlineSpan>[
                          TextSpan(
                              text: "\nSeg á Terça: 08:00h - 19:00h\nSábado e Domingo: 09:00h - 17:00h",
                              style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                              children: <InlineSpan>[
                                TextSpan(
                                    text: "\n\nPreços:",
                                    style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                                    children: <InlineSpan>[
                                      TextSpan(
                                        text: "\n30 min: 1 real\nPor hora: 2 reais",
                                        style: TextStyle(fontSize: 14, color: Colors.black, fontWeight: FontWeight.normal),
                                      )
                                    ]
                                )
                              ]
                          )
                        ]
                    ),
                  ),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("CANCELAR"),
                onPressed: (){
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                textColor: Color(0xFF4B8FFF),
                child: Text("RESERVAR"),
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => InfosPagamento()
                      )
                  );
                },
              )
            ],
          );
        }
    );
  }

  _carregarmarcadores() {

    Set<Marker> marcadoresLocal = {};
    Marker marcador1 = Marker(
        markerId: MarkerId("marcador1"),
        position: LatLng(-22.885751, -47.069082),
        onTap: (){
          _showAlertDialog(context);
        }
    );
    Marker marcador2 = Marker(
        markerId: MarkerId("marcador2"),
        position: LatLng(-22.889942, -47.067472),
        onTap: (){
          _showAlertDialog1(context);
        }
    );
    Marker marcador3 = Marker(
        markerId: MarkerId("marcador3"),
        position: LatLng(-22.887580, -47.068009),
        onTap: (){
          _showAlertDialog2(context);
        }
    );
    Marker marcador4 = Marker(
        markerId: MarkerId("marcador4"),
        position: LatLng(-22.887778, -47.069285),
        onTap: (){
          _showAlertDialog3(context);
        }
    );

    marcadoresLocal.add(marcador1);
    marcadoresLocal.add(marcador2);
    marcadoresLocal.add(marcador3);
    marcadoresLocal.add(marcador4);

    setState(() {
      _marcadores = marcadoresLocal;
    });

    Set<Polygon> listaPolygons = {};
    Polygon polygon1 = const Polygon(
        polygonId: PolygonId("polygon1"),
        fillColor: Colors.transparent,
        strokeColor: Colors.blue,
        strokeWidth: 10,
        points: [
          LatLng(-22.884891, -47.069672),
          LatLng(-22.887850, -47.070469),
          LatLng(-22.891000, -47.068169),
          LatLng(-22.889003, -47.065165),
        ]
    );
    listaPolygons.add(polygon1);

    setState(() {
      _polygons = listaPolygons;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: Stack(
            children: <Widget>[
              GoogleMap(
                mapType: MapType.normal,
                initialCameraPosition: _cameraposition,
                onMapCreated: _onMapCreated,
                myLocationEnabled: true,
                myLocationButtonEnabled: false,
                markers: _marcadores,
                polygons: _polygons,
              ),
              Container(
                alignment: Alignment.topCenter,
                padding: EdgeInsets.only(top: 80),
                child: const Text(
                  "Selecione o marcador que irá reservar:",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    backgroundColor: Colors.white,

                  ),
                )
              ),
            ],
          )
      ),
    );
  }
}