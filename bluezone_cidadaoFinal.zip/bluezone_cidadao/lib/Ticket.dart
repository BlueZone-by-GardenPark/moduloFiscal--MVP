import 'dart:math';
import 'package:bluezone_cidadao/HomePage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_ticket_widget/flutter_ticket_widget.dart';

class TicketWidget extends StatefulWidget {

  String valor;
  String horario;
  String meucpf;
  String datahora;
  String minhaplaca;
  TicketWidget(this.valor, this.horario, this.meucpf, this.datahora, this.minhaplaca);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<TicketWidget> {

    var rng = new Random();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF4B8FFF),
      body: Center(
        child: FlutterTicketWidget(
          width: 350,
          height: 350,
          isCornerRounded: true,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children:  <Widget>[
                    Container(
                      width: 120,
                      height: 25,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(width: 1, color: Colors.green)
                      ),
                      child: Center(
                        child: Text(
                          'Seu Ticket',
                          style: TextStyle(
                              color: Colors.green
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Text(
                          'Nº Pedido: ${rng.nextInt(10000)}',
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Text(
                    '${widget.datahora}',
                    style: TextStyle(
                        color: Colors.black,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 25),
                  child: Column(
                    children: <Widget>[
                      ticketDetailsWidget('Placa', '${widget.minhaplaca}', 'CPF', '${widget.meucpf}'),
                      Padding(
                        padding: const EdgeInsets.only(top: 12, right: 40),
                        child: ticketDetailsWidget('Estadia', '${widget.horario}', 'Valor', 'R\$${widget.valor}'),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 50),
                  child: Center(
                      child: Text(
                          "Obrigado. Volte Sempre!",
                        style: TextStyle(
                          fontWeight: FontWeight.bold
                        ),
                      ),
                  )
                ),
                Padding(
                  padding: EdgeInsets.only(top: 1),
                  child: Center(
                      child: IconButton(
                        icon: Image.asset('imagens/casa.png'),
                        iconSize: 40,
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Home()
                              )
                          );
                        },
                      )
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget ticketDetailsWidget(String firstTitle, String firstDesc, String secondTitle, String secondDesc) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: <Widget>[
      Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              firstTitle,
              style: TextStyle(
                  color: Colors.grey
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                firstDesc,
                style: TextStyle(
                    color: Colors.black
                ),
              ),
            )
          ],
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(right: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              secondTitle,
              style: TextStyle(
                  color: Colors.grey
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                secondDesc,
                style: TextStyle(
                    color: Colors.black
                ),
              ),
            )
          ],
        ),
      )
    ],
  );
}